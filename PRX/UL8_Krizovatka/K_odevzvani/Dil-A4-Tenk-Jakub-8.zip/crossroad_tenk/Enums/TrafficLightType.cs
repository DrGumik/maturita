﻿namespace crossroad_tenk.Enums
{
    public enum TrafficLightType
    {
        Normal,
        Single,
        Pedestrian
    }
}
