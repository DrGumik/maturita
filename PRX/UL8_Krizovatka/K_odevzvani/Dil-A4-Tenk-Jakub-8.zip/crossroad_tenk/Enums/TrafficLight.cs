﻿namespace crossroad_tenk.Enums
{
    public enum TrafficLight
    {
        Red,
        Yellow,
        Green,
        Default
    }
}
